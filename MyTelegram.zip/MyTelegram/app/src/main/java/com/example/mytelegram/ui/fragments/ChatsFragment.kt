package com.example.mytelegram.ui.fragments

import com.example.vovatelegram.R

class ChatsFragment : BaseFragment(R.layout.fragment_chats) {

    // Методы необходимые для данного обьекта
    override fun onResume() {
        super.onResume()
    }
}